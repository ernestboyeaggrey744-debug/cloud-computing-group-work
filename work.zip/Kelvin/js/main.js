document.addEventListener('DOMContentLoaded', function() {
    // Select DOM elements
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    // Toggle mobile menu
    mobileMenuBtn.addEventListener('click', () => {
        mobileMenuBtn.classList.toggle('open');
        navLinks.classList.toggle('open');
        
        // Add accessibility attributes
        if (navLinks.classList.contains('open')) {
            mobileMenuBtn.setAttribute('aria-expanded', 'true');
        } else {
            mobileMenuBtn.setAttribute('aria-expanded', 'false');
        }
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', (event) => {
        if (!event.target.closest('nav') && navLinks.classList.contains('open')) {
            mobileMenuBtn.classList.remove('open');
            navLinks.classList.remove('open');
            mobileMenuBtn.setAttribute('aria-expanded', 'false');
        }
    });
    
    // Close mobile menu when window is resized to desktop size
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768 && navLinks.classList.contains('open')) {
            mobileMenuBtn.classList.remove('open');
            navLinks.classList.remove('open');
            mobileMenuBtn.setAttribute('aria-expanded', 'false');
        }
    });
    
    // Initialize accessibility attribute
    mobileMenuBtn.setAttribute('aria-expanded', 'false');
});